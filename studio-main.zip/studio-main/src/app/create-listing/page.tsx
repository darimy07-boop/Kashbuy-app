import CreateListingForm from '@/components/create-listing-form';

export default function CreateListingPage() {
  return (
    <div className="container mx-auto max-w-4xl py-8 px-4">
      <h1 className="text-3xl md:text-4xl font-bold font-headline mb-8 text-center">
        Create a New Listing
      </h1>
      <CreateListingForm />
    </div>
  );
}
