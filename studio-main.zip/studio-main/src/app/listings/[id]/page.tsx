import Image from 'next/image';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { listings, users } from '@/lib/data';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { Heart, MapPin, MessageCircle, Share2 } from 'lucide-react';
import { Separator } from '@/components/ui/separator';

export default function ListingPage({ params }: { params: { id: string } }) {
  const listing = listings.find((l) => l.id === params.id);

  if (!listing) {
    notFound();
  }

  const { seller } = listing;

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="grid md:grid-cols-3 gap-8 lg:gap-12">
        <div className="md:col-span-2">
          <Card className="overflow-hidden">
            <Carousel className="w-full">
              <CarouselContent>
                {listing.images.map((image, index) => (
                  <CarouselItem key={index}>
                    <div className="aspect-video relative">
                      <Image
                        src={image.url}
                        alt={`${listing.title} - image ${index + 1}`}
                        data-ai-hint={image.hint}
                        fill
                        className="object-cover"
                      />
                    </div>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious className="ml-16" />
              <CarouselNext className="mr-16" />
            </Carousel>
          </Card>
          
          <Card className="mt-6">
              <CardHeader>
                  <CardTitle>Description</CardTitle>
              </CardHeader>
              <CardContent>
                  <p className="text-muted-foreground">{listing.description}</p>
                   <div className="flex flex-wrap gap-2 mt-4">
                    {listing.tags?.map((tag) => (
                        <Badge key={tag} variant="secondary" className="capitalize">{tag}</Badge>
                    ))}
                    </div>
              </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
                <div className="flex justify-between items-start">
                    <div>
                        <Badge>{listing.category}</Badge>
                        <h1 className="text-3xl font-bold font-headline mt-2">{listing.title}</h1>
                        <div className="flex items-center text-muted-foreground text-sm mt-1">
                            <MapPin className="w-4 h-4 mr-1" />
                            <span>Posted in {listing.location}</span>
                        </div>
                    </div>
                    <div className="flex gap-2">
                        <Button variant="ghost" size="icon" aria-label="Share">
                            <Share2 className="h-5 w-5" />
                        </Button>
                        <Button variant="ghost" size="icon" aria-label="Favorite">
                            <Heart className="h-5 w-5" />
                        </Button>
                    </div>
                </div>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold text-primary mb-4">${listing.price.toLocaleString()}</p>
              <Link href="/messages" className="w-full">
                <Button className="w-full text-lg" size="lg">
                    <MessageCircle className="mr-2 h-5 w-5" /> Message Seller
                </Button>
              </Link>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Seller Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center space-x-4">
                <Avatar className="h-16 w-16">
                  <AvatarImage src={seller.avatarUrl} alt={seller.name} />
                  <AvatarFallback>{seller.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-semibold text-lg">{seller.name}</p>
                  <p className="text-sm text-muted-foreground">Member since {new Date(seller.memberSince).getFullYear()}</p>
                </div>
              </div>
              <Separator className="my-4" />
              <Button variant="outline" className="w-full">
                View Profile
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
