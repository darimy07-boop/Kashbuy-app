import Image from 'next/image';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { currentUser, listings } from '@/lib/data';
import ItemCard from '@/components/item-card';
import { MapPin, Calendar, Edit } from 'lucide-react';

export default function ProfilePage({ searchParams }: { searchParams: { tab: string } }) {
  const userListings = listings.filter(l => l.seller.id === currentUser.id);
  const favoriteListings = listings.slice(0, 4); // Mock favorites
  const defaultTab = searchParams.tab || 'listings';

  return (
    <div className="container mx-auto py-8 px-4">
      <Card className="mb-8">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row items-center md:items-start text-center md:text-left gap-6">
            <Avatar className="h-32 w-32 border-4 border-primary/20">
              <AvatarImage src={currentUser.avatarUrl} alt={currentUser.name} />
              <AvatarFallback className="text-4xl">{currentUser.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="flex-grow">
              <h1 className="text-3xl font-bold font-headline">{currentUser.name}</h1>
              <div className="flex flex-wrap justify-center md:justify-start gap-x-4 gap-y-1 text-muted-foreground mt-2">
                <span className="flex items-center"><MapPin className="mr-1.5 h-4 w-4" />{currentUser.location}</span>
                <span className="flex items-center"><Calendar className="mr-1.5 h-4 w-4" />Joined in {new Date(currentUser.memberSince).getFullYear()}</span>
              </div>
              <p className="mt-4 max-w-xl mx-auto md:mx-0">
                Lover of vintage cameras and mid-century furniture. All items from a smoke-free home.
              </p>
            </div>
            <Button variant="outline">
              <Edit className="mr-2 h-4 w-4" /> Edit Profile
            </Button>
          </div>
        </CardContent>
      </Card>
      
      <Tabs defaultValue={defaultTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2 md:w-1/2 mx-auto">
          <TabsTrigger value="listings">My Listings</TabsTrigger>
          <TabsTrigger value="favorites">Favorites</TabsTrigger>
        </TabsList>
        <TabsContent value="listings" className="mt-6">
          <Card>
            <CardHeader>
              <h2 className="text-2xl font-bold">Your Active Listings ({userListings.length})</h2>
            </CardHeader>
            <CardContent>
              {userListings.length > 0 ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {userListings.map((listing) => (
                    <ItemCard key={listing.id} listing={listing} />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12 text-muted-foreground">
                  <p className="mb-4">You haven't listed any items yet.</p>
                  <Button>List an Item</Button>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="favorites" className="mt-6">
          <Card>
            <CardHeader>
              <h2 className="text-2xl font-bold">Your Favorite Listings ({favoriteListings.length})</h2>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {favoriteListings.map((listing) => (
                  <ItemCard key={listing.id} listing={listing} />
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
