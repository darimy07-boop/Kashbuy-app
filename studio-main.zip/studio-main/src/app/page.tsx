import Image from 'next/image';
import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { categories, listings } from '@/lib/data';
import ItemCard from '@/components/item-card';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import AdBanner from '@/components/ad-banner';

export default function Home() {
  const heroImage = PlaceHolderImages.find(img => img.id === 'hero-image');

  return (
    <div className="flex flex-col">
      <section className="relative w-full h-[400px] md:h-[500px] text-white">
        {heroImage && (
          <Image
            src={heroImage.imageUrl}
            alt={heroImage.description}
            data-ai-hint={heroImage.imageHint}
            fill
            className="object-cover"
            priority
          />
        )}
        <div className="absolute inset-0 bg-black/50" />
        <div className="relative z-10 flex flex-col items-center justify-center h-full text-center px-4">
          <h1 className="text-4xl md:text-6xl font-headline font-bold drop-shadow-lg">
            Find Your Next Treasure
          </h1>
          <p className="mt-4 max-w-2xl text-lg md:text-xl drop-shadow">
            Buy and sell new or used items with thousands of locals.
          </p>
          <div className="mt-8 flex w-full max-w-2xl items-center space-x-2">
            <Input
              type="search"
              placeholder="Search for anything..."
              className="flex-1 text-lg p-6 bg-white/90 text-black placeholder:text-muted-foreground"
              aria-label="Search"
            />
            <Button type="submit" size="lg" variant="accent" className="text-lg p-6">
              Search
            </Button>
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16 bg-secondary">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-headline font-bold text-center mb-8">
            Browse Categories
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-8 gap-4 text-center">
            {categories.map((category) => (
              <Link href="#" key={category.id} className="group">
                <Card className="hover:shadow-lg transition-shadow duration-300 transform hover:-translate-y-1">
                  <CardContent className="p-4 flex flex-col items-center justify-center">
                    <category.icon className="w-10 h-10 mb-2 text-primary" />
                    <span className="font-semibold text-sm">{category.name}</span>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-headline font-bold text-center mb-8">
            Featured Listings
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {listings.slice(0, 8).map((listing) => (
              <ItemCard key={listing.id} listing={listing} />
            ))}
          </div>
        </div>
      </section>

      <section className="py-12 md:py-16">
        <div className="container mx-auto px-4">
          <AdBanner />
        </div>
      </section>
      
      <section className="py-12 md:py-16 bg-secondary">
        <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-headline font-bold mb-4">Contact Us</h2>
            <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">Have questions or need help? We're here for you. Reach out to our support team and we'll get back to you as soon as possible.</p>
            <a href="mailto:darimy07@gmail.com">
                <Button size="lg">
                    Email Support
                </Button>
            </a>
        </div>
      </section>
    </div>
  );
}
