import Image from 'next/image';
import { messageThreads, currentUser } from '@/lib/data';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Send, Search } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Separator } from '@/components/ui/separator';

export default function MessagesPage() {
  const activeThread = messageThreads[0];

  return (
    <div className="container mx-auto py-8 px-4 h-[calc(100vh-10rem)]">
      <Card className="h-full">
        <div className="grid md:grid-cols-3 h-full">
          <div className="md:col-span-1 border-r flex flex-col">
            <div className="p-4 border-b">
              <h1 className="text-2xl font-bold font-headline">Messages</h1>
               <div className="relative mt-4">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Search messages..." className="pl-9" />
               </div>
            </div>
            <div className="flex-grow overflow-auto">
              {messageThreads.map((thread, index) => (
                <div
                  key={thread.id}
                  className={cn(
                    'p-4 flex gap-4 cursor-pointer hover:bg-secondary',
                    index === 0 && 'bg-secondary',
                    index !== messageThreads.length - 1 && 'border-b'
                  )}
                >
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={thread.participant.avatarUrl} />
                    <AvatarFallback>{thread.participant.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-grow overflow-hidden">
                    <div className="flex justify-between items-center">
                      <h3 className="font-semibold truncate">{thread.participant.name}</h3>
                      <span className="text-xs text-muted-foreground flex-shrink-0">{thread.lastMessage.timestamp}</span>
                    </div>
                    <p className="text-sm text-muted-foreground truncate">{thread.listing.title}</p>
                    <p className="text-sm text-muted-foreground truncate">{thread.lastMessage.text}</p>
                  </div>
                   {!thread.lastMessage.isRead && (
                    <div className="h-2.5 w-2.5 rounded-full bg-primary self-center flex-shrink-0"></div>
                  )}
                </div>
              ))}
            </div>
          </div>
          <div className="md:col-span-2 hidden md:flex flex-col h-full">
            {activeThread ? (
              <>
                <div className="p-4 border-b flex items-center gap-4">
                  <Avatar>
                    <AvatarImage src={activeThread.participant.avatarUrl} />
                    <AvatarFallback>{activeThread.participant.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <h2 className="font-semibold">{activeThread.participant.name}</h2>
                    <p className="text-sm text-muted-foreground">Regarding: {activeThread.listing.title}</p>
                  </div>
                  <div className="ml-auto">
                    <Image src={activeThread.listing.imageUrl} alt={activeThread.listing.title} width={64} height={64} className="rounded-md object-cover aspect-square" />
                  </div>
                </div>
                <div className="flex-grow p-6 overflow-auto space-y-4">
                    {activeThread.messages.map(message => (
                        <div key={message.id} className={cn("flex items-end gap-2", message.senderId === currentUser.id ? "justify-end" : "justify-start")}>
                           {message.senderId !== currentUser.id && (
                                <Avatar className="h-8 w-8">
                                    <AvatarImage src={activeThread.participant.avatarUrl} />
                                    <AvatarFallback>{activeThread.participant.name.charAt(0)}</AvatarFallback>
                                </Avatar>
                            )}
                            <div className={cn("max-w-xs lg:max-w-md rounded-lg px-4 py-2", message.senderId === currentUser.id ? "bg-primary text-primary-foreground" : "bg-secondary")}>
                                <p>{message.text}</p>
                            </div>
                        </div>
                    ))}
                </div>
                <div className="p-4 border-t mt-auto">
                    <div className="relative">
                        <Input placeholder="Type a message..." className="pr-12 h-12 text-base" />
                        <Button type="submit" size="icon" className="absolute right-2.5 top-1/2 -translate-y-1/2 h-8 w-8">
                            <Send className="h-4 w-4"/>
                        </Button>
                    </div>
                </div>
              </>
            ) : (
              <div className="flex items-center justify-center h-full text-muted-foreground">
                <p>Select a conversation to start chatting</p>
              </div>
            )}
          </div>
        </div>
      </Card>
    </div>
  );
}
