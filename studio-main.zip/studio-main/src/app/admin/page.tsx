import AdminDashboard from '@/components/admin-dashboard';
import { withAdminAuth } from '@/components/withAdminAuth';

function AdminPage() {
  return <AdminDashboard />;
}

export default withAdminAuth(AdminPage);
