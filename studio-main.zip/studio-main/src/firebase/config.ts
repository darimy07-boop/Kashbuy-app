export const firebaseConfig = {
  "projectId": "studio-9237172011-57329",
  "appId": "1:728083614347:web:594da01cdea32bb5ade28e",
  "apiKey": "AIzaSyAwLNQjVkDbLvTgxad7C18j2upZ1ZqlD7s",
  "authDomain": "studio-9237172011-57329.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "728083614347"
};
