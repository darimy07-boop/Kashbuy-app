import type React from 'react';

export type User = {
  id: string;
  name: string;
  avatarUrl: string;
  location: string;
  memberSince: string;
};

export type Category = {
  id: string;
  name: string;
  icon: React.ElementType;
};

export type ListingImage = {
  id: string;
  url: string;
  hint: string;
};

export type Listing = {
  id: string;
  title: string;
  description: string;
  price: number;
  category: string;
  images: ListingImage[];
  location: string;
  seller: User;
  postedDate: string;
  tags?: string[];
};

export type MessageThread = {
  id: string;
  listing: Pick<Listing, 'id' | 'title'> & { imageUrl: string };
  participant: Pick<User, 'id' | 'name' | 'avatarUrl'>;
  messages: Message[];
  lastMessage: {
    text: string;
    timestamp: string;
    isRead: boolean;
  };
};

export type Message = {
  id: string;
  senderId: string;
  text: string;
  timestamp: string;
};
