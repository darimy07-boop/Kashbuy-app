import {
  Car,
  Bike,
  Book,
  Shirt,
  Laptop,
  Sofa,
  Camera,
  PlusCircle,
  Smartphone,
  Watch,
  Paintbrush,
  Guitar
} from 'lucide-react';
import type { Category, User, Listing, MessageThread } from './types';
import { PlaceHolderImages } from './placeholder-images';

const findImage = (id: string) => PlaceHolderImages.find(img => img.id === id) || { id: 'error', url: '', hint: '' };

export const users: User[] = [
  {
    id: 'user-1',
    name: 'Alice',
    avatarUrl: findImage('user-avatar-1').imageUrl,
    location: 'San Francisco, CA',
    memberSince: '2022-01-15',
  },
  {
    id: 'user-2',
    name: 'Bob',
    avatarUrl: findImage('user-avatar-2').imageUrl,
    location: 'New York, NY',
    memberSince: '2021-11-20',
  },
  {
    id: 'user-3',
    name: 'Charlie',
    avatarUrl: findImage('user-avatar-3').imageUrl,
    location: 'Austin, TX',
    memberSince: '2023-03-10',
  },
  {
    id: 'user-4',
    name: 'Diana',
    avatarUrl: findImage('user-avatar-4').imageUrl,
    location: 'Chicago, IL',
    memberSince: '2020-07-22',
  },
];

export const categories: Category[] = [
  { id: 'cat-1', name: 'Cars', icon: Car },
  { id: 'cat-2', name: 'Bikes', icon: Bike },
  { id: 'cat-3', name: 'Books', icon: Book },
  { id: 'cat-4', name: 'Clothing', icon: Shirt },
  { id: 'cat-5', name: 'Electronics', icon: Laptop },
  { id: 'cat-6', name: 'Furniture', icon: Sofa },
  { id: 'cat-7', name: 'Cameras', icon: Camera },
  { id: 'cat-8', name: 'More', icon: PlusCircle },
];

export const allCategories = [
    { id: 'cat-1', name: 'Cars & Vehicles', icon: Car },
    { id: 'cat-2', name: 'Motorcycles', icon: Bike },
    { id: 'cat-3', name: 'Books, Sports & Hobbies', icon: Book },
    { id: 'cat-4', name: 'Fashion & Beauty', icon: Shirt },
    { id: 'cat-5', name: 'Electronics & Appliances', icon: Laptop },
    { id: 'cat-6', name: 'Furniture & Home Decor', icon: Sofa },
    { id: 'cat-9', name: 'Mobiles', icon: Smartphone },
    { id: 'cat-10', name: 'Watches', icon: Watch },
    { id: 'cat-11', name: 'Art', icon: Paintbrush },
    { id: 'cat-12', name: 'Musical Instruments', icon: Guitar },
]

export const listings: Listing[] = [
  {
    id: 'listing-1',
    title: 'Vintage Film Camera',
    description: 'A beautiful vintage film camera in excellent working condition. Perfect for photography enthusiasts and collectors. Comes with a leather case and one roll of film.',
    price: 150,
    category: 'Cameras',
    images: [
        { id: 'img-1-1', url: findImage('vintage-camera').imageUrl, hint: findImage('vintage-camera').imageHint },
        { id: 'img-1-2', url: findImage('vintage-camera-2').imageUrl, hint: findImage('vintage-camera-2').imageHint },
        { id: 'img-1-3', url: findImage('vintage-camera-3').imageUrl, hint: findImage('vintage-camera-3').imageHint },
    ],
    location: 'San Francisco, CA',
    seller: users[0],
    postedDate: '2024-05-20',
    tags: ['photography', 'vintage', 'camera', 'film']
  },
  {
    id: 'listing-2',
    title: 'Comfortable Leather Sofa',
    description: 'Slightly used brown leather sofa. Very comfortable and spacious. No pets, no smoking household. Minor scuff on one arm, otherwise in great shape.',
    price: 400,
    category: 'Furniture',
    images: [{ id: 'img-2-1', url: findImage('leather-sofa').imageUrl, hint: findImage('leather-sofa').imageHint }],
    location: 'New York, NY',
    seller: users[1],
    postedDate: '2024-05-18',
    tags: ['furniture', 'sofa', 'leather', 'living room']
  },
  {
    id: 'listing-3',
    title: 'Pro Mountain Bike',
    description: 'High-performance mountain bike with front suspension. Ridden for one season. Great for trails and cross-country. Recently tuned up.',
    price: 850,
    category: 'Bikes',
    images: [{ id: 'img-3-1', url: findImage('mountain-bike').imageUrl, hint: findImage('mountain-bike').imageHint }],
    location: 'Austin, TX',
    seller: users[2],
    postedDate: '2024-05-21',
    tags: ['bike', 'mountain bike', 'outdoors', 'sports']
  },
  {
    id: 'listing-4',
    title: 'Acoustic Guitar',
    description: 'Beautiful acoustic guitar with a warm tone. Perfect for beginners or intermediate players. Includes a soft case and a few picks.',
    price: 120,
    category: 'Musical Instruments',
    images: [{ id: 'img-4-1', url: findImage('acoustic-guitar').imageUrl, hint: findImage('acoustic-guitar').imageHint }],
    location: 'Chicago, IL',
    seller: users[3],
    postedDate: '2024-05-19',
    tags: ['music', 'guitar', 'acoustic', 'instrument']
  },
  {
    id: 'listing-5',
    title: 'Large Bookshelf',
    description: 'Solid wood bookshelf with 5 shelves. Can hold a lot of books. Some minor wear and tear but very sturdy.',
    price: 75,
    category: 'Furniture',
    images: [{ id: 'img-5-1', url: findImage('bookshelf').imageUrl, hint: findImage('bookshelf').imageHint }],
    location: 'San Francisco, CA',
    seller: users[0],
    postedDate: '2024-05-15',
    tags: ['furniture', 'books', 'storage']
  },
  {
    id: 'listing-6',
    title: 'NextGen Gaming Console',
    description: 'Like-new gaming console with two controllers and all original cables. Barely used. Selling because I don\'t have time to play.',
    price: 450,
    category: 'Electronics',
    images: [{ id: 'img-6-1', url: findImage('gaming-console').imageUrl, hint: findImage('gaming-console').imageHint }],
    location: 'New York, NY',
    seller: users[1],
    postedDate: '2024-05-22',
    tags: ['gaming', 'console', 'electronics', 'video games']
  },
  {
    id: 'listing-7',
    title: 'Professional Camera Drone',
    description: '4K camera drone with 3-axis gimbal. Excellent stability and image quality. Comes with 3 batteries and a carrying case.',
    price: 600,
    category: 'Electronics',
    images: [{ id: 'img-7-1', url: findImage('drone').imageUrl, hint: findImage('drone').imageHint }],
    location: 'Austin, TX',
    seller: users[2],
    postedDate: '2024-05-17',
    tags: ['drone', 'camera', 'electronics', 'photography']
  },
  {
    id: 'listing-8',
    title: 'Italian Espresso Machine',
    description: 'Semi-automatic espresso machine for cafe-quality coffee at home. Stainless steel body. Well-maintained and descaled regularly.',
    price: 300,
    category: 'Electronics & Appliances',
    images: [{ id: 'img-8-1', url: findImage('espresso-machine').imageUrl, hint: findImage('espresso-machine').imageHint }],
    location: 'Chicago, IL',
    seller: users[3],
    postedDate: '2024-05-16',
    tags: ['coffee', 'espresso', 'kitchen', 'appliance']
  },
];

export const messageThreads: MessageThread[] = [
    {
      id: 'thread-1',
      listing: {
        id: 'listing-2',
        title: 'Comfortable Leather Sofa',
        imageUrl: findImage('leather-sofa').imageUrl,
      },
      participant: users[1],
      messages: [
        { id: 'msg-1', senderId: 'current-user', text: 'Hi, is this sofa still available?', timestamp: '2024-05-21T10:00:00Z' },
        { id: 'msg-2', senderId: 'user-2', text: 'Yes, it is!', timestamp: '2024-05-21T10:05:00Z' },
        { id: 'msg-3', senderId: 'current-user', text: 'Great! Would you consider $350?', timestamp: '2024-05-21T10:06:00Z' },
        { id: 'msg-4', senderId: 'user-2', text: 'I can do $380.', timestamp: '2024-05-21T10:15:00Z' },
      ],
      lastMessage: {
        text: 'I can do $380.',
        timestamp: '2 days ago',
        isRead: false,
      },
    },
    {
      id: 'thread-2',
      listing: {
        id: 'listing-4',
        title: 'Acoustic Guitar',
        imageUrl: findImage('acoustic-guitar').imageUrl,
      },
      participant: users[3],
      messages: [
        { id: 'msg-5', senderId: 'current-user', text: 'Hello, what brand is the guitar?', timestamp: '2024-05-20T14:30:00Z' },
        { id: 'msg-6', senderId: 'user-4', text: 'It\'s a Fender. A great starter instrument.', timestamp: '2024-05-20T14:32:00Z' },
      ],
      lastMessage: {
        text: 'It\'s a Fender. A great starter instrument.',
        timestamp: '3 days ago',
        isRead: true,
      },
    },
];

// Assuming the current user is a constant for mock data purposes
export const currentUser: User = {
  id: 'current-user',
  name: 'John Doe',
  avatarUrl: findImage('user-avatar-4').imageUrl,
  location: 'Los Angeles, CA',
  memberSince: '2023-01-01',
};
