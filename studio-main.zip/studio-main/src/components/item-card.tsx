'use client';

import Link from 'next/link';
import Image from 'next/image';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Heart, MapPin } from 'lucide-react';
import type { Listing } from '@/lib/types';
import { Badge } from './ui/badge';

interface ItemCardProps {
  listing: Listing;
}

export default function ItemCard({ listing }: ItemCardProps) {
  const primaryImage = listing.images[0];

  return (
    <Card className="group overflow-hidden flex flex-col h-full animate-in fade-in zoom-in-95 duration-300">
      <Link href={`/listings/${listing.id}`} className="flex flex-col h-full">
        <CardContent className="p-0 flex-grow flex flex-col">
          <div className="relative aspect-video">
            {primaryImage && (
                <Image
                src={primaryImage.url}
                alt={listing.title}
                data-ai-hint={primaryImage.hint}
                fill
                className="object-cover transition-transform duration-300 group-hover:scale-105"
                />
            )}
            <Button
              variant="secondary"
              size="icon"
              className="absolute top-2 right-2 h-8 w-8 rounded-full bg-white/80 hover:bg-white"
              onClick={(e) => {
                e.preventDefault();
                console.log('Favourited!');
              }}
              aria-label="Favorite item"
            >
              <Heart className="h-4 w-4 text-gray-600" />
            </Button>
          </div>
          <div className="p-4 flex-grow flex flex-col">
            <h3 className="font-headline font-semibold text-lg truncate group-hover:text-primary transition-colors">
              {listing.title}
            </h3>
            <div className="flex-grow" />
            <div className="flex items-center text-sm text-muted-foreground mt-2">
              <MapPin className="w-4 h-4 mr-1 flex-shrink-0" />
              <span>{listing.location}</span>
            </div>
          </div>
        </CardContent>
        <CardFooter className="p-4 pt-0">
          <div className="w-full flex justify-between items-center">
             <p className="text-xl font-bold text-primary">
              ${listing.price.toLocaleString()}
            </p>
             <Badge variant="outline">{listing.category}</Badge>
          </div>
        </CardFooter>
      </Link>
    </Card>
  );
}
