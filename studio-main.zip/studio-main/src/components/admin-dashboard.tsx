'use client';

import { Card, CardHeader, CardTitle, CardDescription, CardContent } from '@/components/ui/card';
import { useUser } from '@/firebase';

export default function AdminDashboard() {
    const { user } = useUser();
    return (
        <div className="container mx-auto py-8 px-4">
            <h1 className="text-3xl md:text-4xl font-bold font-headline mb-8">Admin Dashboard</h1>
            <Card>
                <CardHeader>
                    <CardTitle>Welcome, Admin!</CardTitle>
                    <CardDescription>You have successfully accessed the admin-only area.</CardDescription>
                </CardHeader>
                <CardContent>
                    <p>This is your control panel for the Kashbuy Marketplace. More features to manage users, listings, and content will be added here.</p>
                    {user && (
                        <div className="mt-4 p-4 bg-secondary rounded-lg">
                            <h3 className="font-semibold">Current Admin User</h3>
                            <p className="text-sm text-muted-foreground">Email: {user.email}</p>
                            <p className="text-sm text-muted-foreground">UID: {user.uid}</p>
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    );
}
