'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import { useUser } from '@/firebase';
import { useAdmin } from '@/hooks/use-admin';
import { Skeleton } from '@/components/ui/skeleton';

export function withAdminAuth<P extends object>(
  WrappedComponent: React.ComponentType<P>
): React.FC<P> {
  const WithAdminAuth: React.FC<P> = (props) => {
    const { isUserLoading } = useUser();
    const { isAdmin, isAdminLoading } = useAdmin();
    const router = useRouter();

    const isLoading = isUserLoading || isAdminLoading;

    if (isLoading) {
      return (
        <div className="container mx-auto py-8 px-4">
          <div className="space-y-4">
            <Skeleton className="h-12 w-1/3" />
            <Skeleton className="h-64 w-full" />
          </div>
        </div>
      );
    }

    if (!isAdmin) {
      router.replace('/');
      return null;
    }

    return <WrappedComponent {...props} />;
  };

  WithAdminAuth.displayName = `WithAdminAuth(${(WrappedComponent.displayName || WrappedComponent.name || 'Component')})`;

  return WithAdminAuth;
}
