import Image from 'next/image';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { PlaceHolderImages } from '@/lib/placeholder-images';

export default function AdBanner() {
  const adBanner = PlaceHolderImages.find(img => img.id === 'ad-banner');

  // When you're ready to integrate a real ad network like Google AdSense,
  // you would replace this placeholder with the script they provide.
  // It might look something like this:
  /*
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-YOUR_CLIENT_ID"
     crossOrigin="anonymous"></script>
    <ins class="adsbygoogle"
        style={{ display: 'block' }}
        data-ad-client="ca-pub-YOUR_CLIENT_ID"
        data-ad-slot="YOUR_AD_SLOT_ID"
        data-ad-format="auto"
        data-full-width-responsive="true"></ins>
    <script>
        (adsbygoogle = window.adsbygoogle || []).push({});
    </script>
  */

  if (!adBanner) {
    return null;
  }

  return (
    <Card className="overflow-hidden">
      <div className="relative aspect-[1000/120]">
        <Image
          src={adBanner.imageUrl}
          alt={adBanner.description}
          data-ai-hint={adBanner.imageHint}
          fill
          className="object-cover"
        />
        <div className="absolute top-2 right-2">
          <Badge variant="secondary" className="text-xs">Ad</Badge>
        </div>
      </div>
    </Card>
  );
}
