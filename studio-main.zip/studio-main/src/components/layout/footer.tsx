import Link from 'next/link';
import { Package } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t bg-secondary">
      <div className="container mx-auto py-8 px-4">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center gap-2 mb-4 md:mb-0">
            <Package className="h-6 w-6 text-primary" />
            <span className="text-xl font-bold font-headline text-primary">Kashbuy</span>
          </div>
          <nav className="flex flex-wrap justify-center gap-4 md:gap-6 text-sm text-muted-foreground">
            <Link href="#" className="hover:text-primary transition-colors">About Us</Link>
            <Link href="#" className="hover:text-primary transition-colors">Contact</Link>
            <Link href="#" className="hover:text-primary transition-colors">Terms of Service</Link>
            <Link href="#" className="hover:text-primary transition-colors">Privacy Policy</Link>
          </nav>
          <div className="mt-4 md:mt-0">
            <p className="text-sm text-muted-foreground">&copy; {new Date().getFullYear()} Kashbuy. All rights reserved.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
