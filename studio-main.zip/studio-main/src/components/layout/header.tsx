'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import {
  Search,
  Package,
  MessageCircle,
  User as UserIcon,
  LogOut,
  Heart,
  LogIn,
  Shield,
} from 'lucide-react';
import { useUser, useAuth } from '@/firebase';
import { signOut } from 'firebase/auth';
import { useRouter } from 'next/navigation';
import { useAdmin } from '@/hooks/use-admin';

const Logo = () => (
  <Link href="/" className="flex items-center gap-2">
    <Package className="h-8 w-8 text-primary" />
    <span className="text-2xl font-bold font-headline text-primary">Kashbuy</span>
  </Link>
);

export default function Header() {
  const { user, isUserLoading } = useUser();
  const { isAdmin, isAdminLoading } = useAdmin();
  const auth = useAuth();
  const router = useRouter();

  const handleLogout = async () => {
    if(auth) {
      await signOut(auth);
      router.push('/');
    }
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-card shadow-sm">
      <div className="container mx-auto flex h-16 items-center px-4">
        <div className="mr-4 hidden md:flex">
          <Logo />
        </div>

        <div className="flex w-full items-center justify-between md:justify-start gap-4">
          <div className="md:hidden">
            <Logo />
          </div>

          <div className="hidden sm:flex flex-1 max-w-md items-center">
            <Input
              type="search"
              placeholder="Search items..."
              className="h-10 rounded-r-none focus:ring-0 focus:ring-offset-0 border-r-0"
            />
            <Button type="submit" size="icon" className="h-10 rounded-l-none" variant="accent">
              <Search className="h-5 w-5" />
            </Button>
          </div>

          <div className="flex items-center gap-2 sm:gap-4">
            {user && (
              <Link href="/create-listing">
                <Button variant="accent">List an Item</Button>
              </Link>
            )}

            {isUserLoading || isAdminLoading ? (
              <div className="h-10 w-10 bg-muted rounded-full animate-pulse" />
            ) : user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-10 w-10 rounded-full">
                    <Avatar className="h-10 w-10">
                      {user.photoURL && (
                        <AvatarImage src={user.photoURL} alt={user.displayName || 'User'} />
                      )}
                      <AvatarFallback>
                        {user.displayName ? user.displayName.charAt(0) : <UserIcon />}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56" align="end" forceMount>
                  <DropdownMenuLabel className="font-normal">
                    <div className="flex flex-col space-y-1">
                      <p className="text-sm font-medium leading-none">
                        {user.displayName || 'Anonymous User'}
                      </p>
                      <p className="text-xs leading-none text-muted-foreground">
                        {user.email || 'No email provided'}
                      </p>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  {isAdmin && (
                    <DropdownMenuItem asChild>
                      <Link href="/admin">
                        <Shield className="mr-2 h-4 w-4" />
                        Admin Dashboard
                      </Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuItem asChild>
                    <Link href="/profile">
                      <UserIcon className="mr-2 h-4 w-4" />
                      Profile
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/profile?tab=favorites">
                      <Heart className="mr-2 h-4 w-4" />
                      Favorites
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link href="/messages">
                      <MessageCircle className="mr-2 h-4 w-4" />
                      Messages
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="mr-2 h-4 w-4" />
                    Log out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Link href="/login">
                <Button>
                  <LogIn className="mr-2 h-4 w-4" /> Login
                </Button>
              </Link>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
